/**
 * Anti-delete and anti-edit. Both arrive through the same `messages.update` event, so both live here.
 *
 *   deleted message   resent as it was (no extra text), carrying an "ad reply" card: Deleted Message / Deleted by ...
 *   edited message    the old and the new text in one message, with the same card: Edited Message / Edited by ...
 *
 * Groups: the notice goes into the group. Private chats: it goes to the bot's own inbox.
 * Switched with the `antidelete` and `antiedit` commands.
 */
import {
	generateWAMessageFromContent,
	getContentType,
	isJidGroup,
	jidNormalizedUser,
	normalizeMessageContent
} from 'baileys';
import { getAnti, getAntiEdit, getConfig, messageDb } from '#sql';
import { applyFont } from './fontlist.js';

const SOURCE_URL = 'https://www.youtube.com/@Terrizev';
const FALLBACK_AVATAR = 'https://i.ibb.co/2kR6bDq/avatar-contact.png';
const AVATAR_TIMEOUT_MS = 5000;

const TEXT_TYPES = new Set(['conversation', 'extendedTextMessage']);

const withTimeout = (promise, ms) =>
	Promise.race([
		promise,
		new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms).unref?.())
	]);

// the sender's profile picture, or a default one (no picture, hidden by privacy settings, or too slow)
const profilePicture = async (conn, jid) => {
	try {
		return (await withTimeout(conn.profilePictureUrl(jid, 'image'), AVATAR_TIMEOUT_MS)) || FALLBACK_AVATAR;
	} catch {
		return FALLBACK_AVATAR;
	}
};

const adReply = (title, body, thumbnailUrl) => ({
	title,
	body,
	thumbnailUrl,
	sourceUrl: SOURCE_URL,
	mediaType: 1,
	renderLargerThumbnail: false
});

const displayName = async (conn, jid) => {
	try {
		return (await conn.getName(jid)) || jid.split('@')[0];
	} catch {
		return jid.split('@')[0];
	}
};

const resolve = async (conn, jid, alt) => {
	if (!jid) return jid;
	try {
		return await conn.resolveJid(jid, alt);
	} catch {
		return jid;
	}
};

// the bot's own wording follows the .font setting (this module sends through the socket, not Message.send)
const fontStyler = async () => {
	let fontStyle = 1;
	try {
		({ fontStyle } = await getConfig());
	} catch {
		// no config available, send plain text
	}
	return text => (fontStyle && fontStyle !== 1 ? applyFont(text, fontStyle) : text);
};

const typeOf = stored => stored.type || getContentType(stored.message);

// the text of a message, or the caption of a photo / video / document
const textOf = content => {
	const message = normalizeMessageContent(content);
	if (!message) return '';
	const inner = message[getContentType(message)];
	if (typeof inner === 'string') return inner;
	return inner?.text || inner?.caption || '';
};

/* ───────────────────────────── deleted messages ───────────────────────────── */

// Resends a stored message (photo, video, voice note, sticker, document...) as it was, quoting the deleted
// message, with `contextInfo` swapped for the ad-reply card. The media is relayed, nothing is downloaded.
const resend = async (conn, target, original, contextInfo) => {
	const content = JSON.parse(JSON.stringify(original.message));
	const type = content[typeOf(original)] ? typeOf(original) : getContentType(content);
	if (!type || !content[type] || typeof content[type] !== 'object') throw new Error('nothing to resend');

	delete content[type].viewOnce; // a deleted view-once is kept as a normal photo / video
	content[type].contextInfo = contextInfo;

	const message = generateWAMessageFromContent(target, content, { quoted: original, userJid: conn.user.id });
	await conn.relayMessage(target, message.message, { messageId: message.key.id });
};

async function handleDelete(conn, update) {
	const store = await conn.loadMessage(update.key.id);
	const original = store?.message;
	if (!original?.message) return;

	const isGroup = isJidGroup(store.jid);
	if (!(await getAnti(isGroup ? 'gc' : 'dm'))) return;

	const owner = jidNormalizedUser(conn.user.id);
	const sender = original.sender || (await resolve(conn, original.key.participant || original.key.remoteJid));
	const deletedBy = isGroup
		? await resolve(conn, update.key.participant, update.key.participantAlt)
		: update.key.fromMe
			? owner
			: await resolve(conn, update.key.remoteJid, update.key.remoteJidAlt);

	const contextInfo = {
		mentionedJid: [...new Set([sender, deletedBy].filter(Boolean))],
		externalAdReply: adReply(
			'Deleted Message',
			`Deleted by ${await displayName(conn, deletedBy || sender)}`,
			await profilePicture(conn, sender)
		)
	};
	const target = isGroup ? store.jid : owner;

	if (TEXT_TYPES.has(typeOf(original))) {
		// nothing to show but the words themselves: they are the message, with the card
		const text = textOf(original.message);
		if (!text) return;
		await conn.sendMessage(target, { text, contextInfo }, { quoted: original });
		return;
	}
	await resend(conn, target, original, contextInfo);
}

/* ───────────────────────────── edited messages ───────────────────────────── */

// Baileys hands an edit over as an update whose message is { editedMessage: { message } }
const readEdit = update => {
	const message = update?.update?.message;
	return message?.editedMessage?.message ?? message?.protocolMessage?.editedMessage ?? null;
};

// Keeps the stored copy up to date, so the next edit (or a delete) works from the latest wording.
const storeNewText = async (store, original, text) => {
	const type = typeOf(original);
	const inner = original.message[type];
	if (type === 'conversation') original.message.conversation = text;
	else if (inner && typeof inner === 'object') inner[type === 'extendedTextMessage' ? 'text' : 'caption'] = text;
	original.body = text;
	await messageDb.update({ message: original }, { where: { id: store.id } });
};

async function handleEdit(conn, update) {
	const edited = readEdit(update);
	if (!edited || !update.key?.id) return;

	const store = await conn.loadMessage(update.key.id);
	const original = store?.message;
	// the bot edits its own messages all the time ("Please wait..." -> the result), and those are not stored
	if (!original?.message || original.key?.fromMe) return;
	if (typeOf(original) === 'protocolMessage') return; // the edit notice itself, not the message that was edited

	const oldText = textOf(original.message);
	const newText = textOf(edited);
	if (!newText || newText === oldText) return;

	const isGroup = isJidGroup(store.jid);
	if (await getAntiEdit(isGroup ? 'gc' : 'dm')) {
		const owner = jidNormalizedUser(conn.user.id);
		const sender = original.sender || (await resolve(conn, original.key.participant || original.key.remoteJid));
		const style = await fontStyler();

		const text =
			`${style('📝 Edited Message (Original):')}\n\n${oldText || '—'}\n\n` +
			`${style('✏️ Edited Message (New):')}\n\n${newText}`;
		const contextInfo = {
			mentionedJid: [sender],
			externalAdReply: adReply(
				'Edited Message',
				`Edited by ${await displayName(conn, sender)}`,
				await profilePicture(conn, sender)
			)
		};
		await conn.sendMessage(isGroup ? store.jid : owner, { text, contextInfo }, { quoted: original });
	}

	await storeNewText(store, original, newText);
}

/* ───────────────────────────── entry point ───────────────────────────── */

export const AntiDelete = async (conn, updates) => {
	for (const update of updates) {
		try {
			if (update.key && (update.update?.deleteMessage || update.update?.message === null)) {
				await handleDelete(conn, update);
			} else {
				await handleEdit(conn, update);
			}
		} catch (err) {
			console.log('[antidelete]', err?.message || err);
		}
	}
};
