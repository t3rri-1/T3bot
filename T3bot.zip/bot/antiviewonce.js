import { getSettings, isSudo, loadMessage } from '#sql';
import { downloadMediaMessage, isJidGroup, jidNormalizedUser } from 'baileys';
import { MAX_MEDIA_MB } from '../lib/resources.js';

export async function AntiViewOnce(msg) {
	if (!msg.viewonce) return;

	const settings = await getSettings();
	if (!settings.isEnabled) return;

	const isGroup = isJidGroup(msg.from);
	if (settings.type === 'gc' && !isGroup) return;
	if (settings.type === 'dm' && isGroup) return;

	const modifiedMessage = JSON.parse(JSON.stringify(msg.message));
	const messageType = Object.keys(modifiedMessage)[0];

	if (modifiedMessage[messageType]) {
		delete modifiedMessage[messageType].viewOnce;
		modifiedMessage[messageType].contextInfo = {
			stanzaId: msg.key.id,
			participant: msg.sender,
			quotedMessage: msg.message,
		};
	}

	await msg.client.relayMessage(msg.from, modifiedMessage, {});
}

/**
 * React to a view-once message (any emoji) and it is sent to your bot inbox, as a normal photo / video / voice
 * note. Works for the owner and for sudo users, who each get it in their own chat with the bot.
 *
 * The media has to still be on WhatsApp's servers, so react before the view-once is opened.
 */
const KINDS = { imageMessage: 'image', videoMessage: 'video', audioMessage: 'audio' };
const saved = new Map(); // "inbox:message id" -> time, so a reaction WhatsApp delivers twice sends once

const bytesOf = length =>
	length && typeof length === 'object' ? (length.low ?? 0) + (length.high ?? 0) * 2 ** 32 : Number(length) || 0;

export async function ViewOnceReact(msg) {
	try {
		const reaction = msg.message?.reactionMessage;
		const targetId = reaction?.key?.id;
		if (!targetId || !reaction.text) return; // empty text: the reaction was taken back

		const conn = msg.client;
		if (!msg.key.fromMe && !(await isSudo(msg.sender, msg.user))) return;

		const stored = (await loadMessage(targetId))?.message;
		const type = stored?.type;
		const media = stored?.message?.[type];
		if (!media || !KINDS[type] || !(stored.viewonce || media.viewOnce)) return;

		// the bot's own inbox when the owner reacts, the sudo user's chat with the bot otherwise
		const inbox = msg.key.fromMe ? jidNormalizedUser(conn.user.id) : msg.sender;
		const stamp = `${inbox}:${targetId}`;
		if (saved.has(stamp)) return;
		saved.set(stamp, Date.now());
		if (saved.size > 200) saved.delete(saved.keys().next().value);

		if (bytesOf(media.fileLength) > MAX_MEDIA_MB * 1024 * 1024) {
			await conn.sendMessage(inbox, { text: `_That view-once is over this host's ${MAX_MEDIA_MB} MB media limit._` });
			return;
		}

		let buffer;
		try {
			buffer = await downloadMediaMessage(
				{ key: stored.key, message: stored.message },
				'buffer',
				{},
				{ logger: console, reuploadRequest: conn.updateMediaMessage }
			);
		} catch (err) {
			saved.delete(stamp); // let a second reaction try again
			console.log('[viewonce-react] download failed:', err?.message || err);
			await conn.sendMessage(inbox, {
				text: '_Could not get that view-once, it was probably opened already or has expired._'
			});
			return;
		}

		const kind = KINDS[type];
		const content = { [kind]: buffer };
		if (media.caption) content.caption = media.caption;
		if (kind === 'video' && media.gifPlayback) content.gifPlayback = true;
		if (kind === 'audio') {
			content.mimetype = media.mimetype || 'audio/ogg; codecs=opus';
			content.ptt = !!media.ptt;
		}
		await conn.sendMessage(inbox, content);
	} catch (err) {
		console.log('[viewonce-react]', err?.message || err);
	}
}
